//offusca
const offusca = require('./verifica.js').offusca;

test('test01', () => {
    expect(offusca('ciao')).toBe('C140');
    expect(offusca('ciao')).toBe('CI40');   //errore: C140
});

//calcola
const calcola = require('./verifica.js').calcola;

test ('test01', () => {
    expect(calcola('sin(x) + 1', 1.5)).toBe(1.9974949866040546);
    expect(calcola('sin(x) + 1', 1.5)).toBe(1.5);   //errore: 1.9974949866040546
});